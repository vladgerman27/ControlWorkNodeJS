module.exports = {
    mongoURI: 'mongodb+srv://Abdiyev096:87023548049BOSS@cluster0.bor8n.mongodb.net/my_social_network?retryWrites=true&w=majority'
}